import Std
set_option autoImplicit false
theorem candidate_5d5ebcd187bad6b4f3eaef1294b1a847c1f4502858c83d67a55499d738674544 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [31479]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [31479]).drop k) (ys.drop k) := by
  intros
  simp [List.drop_zipWith, List.map_zipWith]
#print axioms candidate_5d5ebcd187bad6b4f3eaef1294b1a847c1f4502858c83d67a55499d738674544
theorem candidate_297408b767656b0f255731cbf416c78409735634cb3a546cbd33e984fc1bfa9b : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[31479]]).flatten.reverse).map f = (((xss ++ [[31479]]).map List.reverse).reverse.map (List.map f)).flatten := by
  intros
  simp [List.reverse_flatten]
#print axioms candidate_297408b767656b0f255731cbf416c78409735634cb3a546cbd33e984fc1bfa9b
theorem candidate_264cbcb0274dbeb33b138922a19fcbe2ed4d539f134d525f9863ab12d285e9a5 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).takeWhile p).dropWhile q = (((xs ++ [31479]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  intros
  simp only [List.dropWhile_map, List.takeWhile_map]
#print axioms candidate_264cbcb0274dbeb33b138922a19fcbe2ed4d539f134d525f9863ab12d285e9a5
theorem candidate_63550e9a141845ccc98f323bb1601d01d56d8b71fccc12b136afba7b0fde219c : ∀ (xss : List (List Nat)), ((xss ++ [[31479]]).flatten.reverse).count 31479 = ((xss ++ [[31479]]).map (List.count 31479)).sum := by
  intros
  simp only [List.count_flatten, List.count_reverse, List.map_append]
#print axioms candidate_63550e9a141845ccc98f323bb1601d01d56d8b71fccc12b136afba7b0fde219c
theorem candidate_cf17e5657994f1e93316fb5a8a0883cd5d42fa401cc428f960e5d5fd6b6ad3ff : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 31479) b) c = Nat.gcd (a + 31479) (Nat.gcd c b) := by
  intros
  rw [Nat.gcd_assoc] <;> congr 1 <;> apply Nat.gcd_comm
#print axioms candidate_cf17e5657994f1e93316fb5a8a0883cd5d42fa401cc428f960e5d5fd6b6ad3ff
theorem candidate_4f0fd2937f59d9ca50153bb99d9b975c9a199edbd539f47b218985a989889fbd : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  intros
  simp [List.reverse_flatMap]
#print axioms candidate_4f0fd2937f59d9ca50153bb99d9b975c9a199edbd539f47b218985a989889fbd
theorem candidate_601b950a3ea51e3f48442d41edfed8f328853ee98d1af1f0d2af56d170cabe45 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  intros
  simp [List.reverse_take]
#print axioms candidate_601b950a3ea51e3f48442d41edfed8f328853ee98d1af1f0d2af56d170cabe45
theorem candidate_500161c20d0ee1e6898433e7f4ae388ba9e026ab8f113c45fbb806f955b3c6ee : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).dropWhile p).takeWhile q = (((xs ++ [31479]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  intros
  simp only [List.dropWhile_map, List.takeWhile_map]
#print axioms candidate_500161c20d0ee1e6898433e7f4ae388ba9e026ab8f113c45fbb806f955b3c6ee
