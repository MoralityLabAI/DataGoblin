import Std
theorem negative_control : False := by exact True.intro
