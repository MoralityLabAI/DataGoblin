theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.append_assoc]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.reverse_reverse]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap]

theorem dgCert4 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 65660) b) c + 65660 = Nat.gcd (a + 65660) (Nat.gcd c b) + 65660 := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 2 <;> apply Nat.gcd_comm

theorem dgCert5 : ∀ (xss : List (List Nat)), ((xss ++ [[69263]]).flatten.reverse).count 69263 = ((xss ++ [[69263]]).map (List.count 69263)).sum := by
  repeat' intro
  simp only [List.count_flatten, List.count_reverse, List.map_append]

theorem dgCert6 : ∀ (xss : List (List Nat)), ((xss ++ [[69263]]).flatten.reverse).count 69263 = ((xss ++ [[69263]]).map (List.count 69263)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.count_flatten]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).takeWhile p).dropWhile q = (((xs ++ [39622]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
