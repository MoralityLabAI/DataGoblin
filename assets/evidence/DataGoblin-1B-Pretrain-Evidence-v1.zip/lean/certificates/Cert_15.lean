theorem dgCert0 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [69263]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [69263]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_zipWith, List.map_zipWith]

theorem dgCert1 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [69263]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [69263]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert2 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [69263]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [69263]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_zipWith, List.map_zipWith]

theorem dgCert3 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[50042]]).flatten.reverse).take k).map f = ((((xss ++ [[50042]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.flatten_append, List.map_take, List.reverse_flatten]

theorem dgCert4 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[50042]]).flatten.reverse).take k).map f = ((((xss ++ [[50042]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert5 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[50042]]).flatten.reverse).take k).map f = ((((xss ++ [[50042]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_take, List.reverse_flatten]

theorem dgCert6 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[50042]]).flatten.reverse).take k).map f = ((((xss ++ [[50042]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert7 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[50042]]).flatten.reverse).take k).map f = ((((xss ++ [[50042]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_take, List.map_flatten]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
