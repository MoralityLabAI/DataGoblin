theorem dgCert0 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp only [List.reverse_append, List.reverse_take, List.length_drop]

theorem dgCert1 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp only [List.reverse_append, List.reverse_take]

theorem dgCert2 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp only [List.reverse_take, List.reverse_append]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).dropWhile p).takeWhile q = (((xs ++ [69263]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).dropWhile p).takeWhile q = (((xs ++ [69263]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).dropWhile p).takeWhile q = (((xs ++ [69263]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert6 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [39622]) ++ ys).filterMap f).map g = (xs ++ [39622]).filterMap (fun x => (f x).map g) ++ ys.filterMap (fun x => (f x).map g) := by
  repeat' intro
  simp only [List.filterMap_append, List.map_append, List.map_filterMap]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [34819]).take k).reverse).map f = (([34819].reverse ++ xs.reverse).map f).drop ((xs ++ [34819]).length - k) := by
  repeat' intro
  simp [List.map_append, List.map_drop, List.reverse_take]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
