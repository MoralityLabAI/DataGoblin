theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.append_assoc]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.reverse_reverse]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap]

theorem dgCert4 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[39622]]).flatten.reverse).map f = (((xss ++ [[39622]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.flatten_append, List.reverse_flatten]

theorem dgCert5 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[39622]]).flatten.reverse).map f = (((xss ++ [[39622]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert6 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[39622]]).flatten.reverse).map f = (((xss ++ [[39622]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert7 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[39622]]).flatten.reverse).map f = (((xss ++ [[39622]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_flatten]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
