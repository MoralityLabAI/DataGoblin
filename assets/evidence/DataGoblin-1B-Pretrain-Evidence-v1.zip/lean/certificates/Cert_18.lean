theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).takeWhile p).dropWhile q = (((xs ++ [31479]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).takeWhile p).dropWhile q = (((xs ++ [31479]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).takeWhile p).dropWhile q = (((xs ++ [31479]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).takeWhile p).dropWhile q = (((xs ++ [31479]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map]

theorem dgCert4 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [34819]) ++ ys).filterMap f).reverse.map g = (ys.filterMap (fun x => (f x).map g)).reverse ++ ((xs ++ [34819]).filterMap (fun x => (f x).map g)).reverse := by
  repeat' intro
  simp only [List.filterMap_append, List.reverse_append, List.map_reverse, List.map_append, List.map_filterMap]

theorem dgCert5 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [50042]) ++ ys).filterMap f).reverse.map g = (ys.filterMap (fun x => (f x).map g)).reverse ++ ((xs ++ [50042]).filterMap (fun x => (f x).map g)).reverse := by
  repeat' intro
  simp only [List.filterMap_append, List.reverse_append, List.map_reverse, List.map_append, List.map_filterMap]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).takeWhile p).dropWhile q = (((xs ++ [69263]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).takeWhile p).dropWhile q = (((xs ++ [69263]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
