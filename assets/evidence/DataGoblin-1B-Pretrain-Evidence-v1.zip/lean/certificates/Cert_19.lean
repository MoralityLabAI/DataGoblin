theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).takeWhile p).dropWhile q = (((xs ++ [69263]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [69263]).map f).takeWhile p).dropWhile q = (((xs ++ [69263]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map]

theorem dgCert2 : ∀ (xss yss : List (List Nat)), (((xss ++ [[65660]]) ++ yss).flatten.reverse).count 65660 = (xss.map (List.count 65660)).sum + 1 + (yss.map (List.count 65660)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.flatten_append, List.count_append, List.flatten_singleton, List.count_cons_self, List.count_nil, Nat.zero_add, List.count_flatten]

theorem dgCert3 : ∀ (xss yss : List (List Nat)), (((xss ++ [[34819]]) ++ yss).flatten.reverse).count 34819 = (xss.map (List.count 34819)).sum + 1 + (yss.map (List.count 34819)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.flatten_append, List.count_append, List.flatten_singleton, List.count_cons_self, List.count_nil, Nat.zero_add, List.count_flatten]

theorem dgCert4 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [31479]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [31479]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert5 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [31479]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [31479]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_zipWith, List.map_zipWith]

theorem dgCert6 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [31479]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [31479]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert7 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [31479]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [31479]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_zipWith, List.map_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
