theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp only [List.reverse_take, List.reverse_append, List.map_drop]

theorem dgCert1 : ∀ (xss : List (List Nat)), ((xss ++ [[61098]]).flatten.reverse).count 61098 = ((xss ++ [[61098]]).map (List.count 61098)).sum := by
  repeat' intro
  simp only [List.count_flatten, List.count_reverse, List.map_append]

theorem dgCert2 : ∀ (xss : List (List Nat)), ((xss ++ [[61098]]).flatten.reverse).count 61098 = ((xss ++ [[61098]]).map (List.count 61098)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.count_flatten]

theorem dgCert3 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [56603]) ++ ys).filterMap f).reverse.map g = (ys.filterMap (fun x => (f x).map g)).reverse ++ ((xs ++ [56603]).filterMap (fun x => (f x).map g)).reverse := by
  repeat' intro
  simp only [List.filterMap_append, List.reverse_append, List.map_reverse, List.map_append, List.map_filterMap]

theorem dgCert4 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [56603]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [56603]).take k) (ys.take k) := by
  repeat' intro
  simp [List.map_zipWith, List.take_zipWith]

theorem dgCert5 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [56603]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [56603]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert6 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [56603]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [56603]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_zipWith, List.map_zipWith]

theorem dgCert7 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [56603]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [56603]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.map_zipWith, List.take_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
