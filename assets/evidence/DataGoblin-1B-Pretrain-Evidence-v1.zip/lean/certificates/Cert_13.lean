theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).takeWhile p).dropWhile q = (((xs ++ [39622]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).takeWhile p).dropWhile q = (((xs ++ [39622]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).takeWhile p).dropWhile q = (((xs ++ [39622]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map]

theorem dgCert3 : ∀ (xss yss : List (List Nat)), (((xss ++ [[50042]]) ++ yss).flatten.reverse).count 50042 = (xss.map (List.count 50042)).sum + 1 + (yss.map (List.count 50042)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.flatten_append, List.count_append, List.flatten_singleton, List.count_cons_self, List.count_nil, Nat.zero_add, List.count_flatten]

theorem dgCert4 : ∀ (xss : List (List Nat)), ((xss ++ [[39622]]).flatten.reverse).count 39622 = ((xss ++ [[39622]]).map (List.count 39622)).sum := by
  repeat' intro
  simp only [List.count_flatten, List.count_reverse, List.map_append]

theorem dgCert5 : ∀ (xss : List (List Nat)), ((xss ++ [[39622]]).flatten.reverse).count 39622 = ((xss ++ [[39622]]).map (List.count 39622)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.count_flatten]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_append, List.reverse_flatMap]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap, List.reverse_reverse]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
