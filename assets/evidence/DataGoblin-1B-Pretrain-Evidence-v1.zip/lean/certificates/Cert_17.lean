theorem dgCert0 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [69263]).take k).reverse = ([69263].reverse ++ xs.reverse).drop ((xs ++ [69263]).length - k) := by
  repeat' intro
  simp only [List.reverse_take, List.reverse_append]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool) (k : Nat), ((((xs ++ [65660]).map f).dropWhile p).takeWhile q).drop k = ((((xs ++ [65660]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).drop k).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map, List.map_drop]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool) (k : Nat), ((((xs ++ [34819]).map f).dropWhile p).takeWhile q).drop k = ((((xs ++ [34819]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).drop k).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map, List.map_drop]

theorem dgCert3 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[56603]]).flatten.reverse).take k).map f = ((((xss ++ [[56603]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.flatten_append, List.map_take, List.reverse_flatten]

theorem dgCert4 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[56603]]).flatten.reverse).take k).map f = ((((xss ++ [[56603]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert5 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[56603]]).flatten.reverse).take k).map f = ((((xss ++ [[56603]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_take, List.reverse_flatten]

theorem dgCert6 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[56603]]).flatten.reverse).take k).map f = ((((xss ++ [[56603]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert7 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[56603]]).flatten.reverse).take k).map f = ((((xss ++ [[56603]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_take, List.map_flatten]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
