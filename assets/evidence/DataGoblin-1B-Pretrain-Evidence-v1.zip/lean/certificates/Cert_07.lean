theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).dropWhile p).takeWhile q = (((xs ++ [61098]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert1 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 69263) b) c = Nat.gcd (a + 69263) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 1 <;> apply Nat.gcd_comm

theorem dgCert2 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 69263) b) c = Nat.gcd (a + 69263) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> exact congrArg (Nat.gcd _) (Nat.gcd_comm _ _)

theorem dgCert3 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[65660]]).flatten.reverse).take k).map f = ((((xss ++ [[65660]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.flatten_append, List.map_take, List.reverse_flatten]

theorem dgCert4 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[65660]]).flatten.reverse).take k).map f = ((((xss ++ [[65660]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert5 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[65660]]).flatten.reverse).take k).map f = ((((xss ++ [[65660]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_take, List.reverse_flatten]

theorem dgCert6 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[65660]]).flatten.reverse).take k).map f = ((((xss ++ [[65660]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert7 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[65660]]).flatten.reverse).take k).map f = ((((xss ++ [[65660]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_take, List.map_flatten]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
