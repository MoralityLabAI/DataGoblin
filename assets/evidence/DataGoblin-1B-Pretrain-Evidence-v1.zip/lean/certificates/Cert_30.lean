theorem dgCert0 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [50042]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [50042]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_zipWith, List.map_zipWith]

theorem dgCert1 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [50042]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [50042]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.map_zipWith, List.take_zipWith]

theorem dgCert2 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [50042]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [50042]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert3 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [50042]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [50042]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_zipWith, List.map_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3
