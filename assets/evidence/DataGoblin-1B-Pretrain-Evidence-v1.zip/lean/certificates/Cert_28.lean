theorem dgCert0 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[61098]]).flatten.reverse).map f = (((xss ++ [[61098]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.flatten_append, List.reverse_flatten]

theorem dgCert1 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[61098]]).flatten.reverse).map f = (((xss ++ [[61098]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert2 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[61098]]).flatten.reverse).map f = (((xss ++ [[61098]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert3 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[61098]]).flatten.reverse).map f = (((xss ++ [[61098]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_flatten]

theorem dgCert4 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [65660]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [65660]).take k) (ys.take k) := by
  repeat' intro
  simp [List.map_zipWith, List.take_zipWith]

theorem dgCert5 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [65660]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [65660]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert6 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [65660]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [65660]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_zipWith, List.map_zipWith]

theorem dgCert7 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [65660]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [65660]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.map_zipWith, List.take_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
