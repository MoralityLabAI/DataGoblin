theorem dgCert0 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [34819]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [34819]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.map_zipWith, List.take_zipWith]

theorem dgCert1 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [34819]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [34819]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert2 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [34819]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [34819]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_zipWith, List.map_zipWith]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_append, List.reverse_flatMap]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap, List.reverse_reverse]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap, List.reverse_reverse]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
