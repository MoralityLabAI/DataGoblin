theorem dgCert0 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [65660]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [65660]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert1 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [65660]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [65660]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_zipWith, List.map_zipWith]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).takeWhile p).dropWhile q = (((xs ++ [61098]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).takeWhile p).dropWhile q = (((xs ++ [61098]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).takeWhile p).dropWhile q = (((xs ++ [61098]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).takeWhile p).dropWhile q = (((xs ++ [61098]).takeWhile (p ∘ f)).dropWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map]

theorem dgCert6 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [50042]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [50042]).take k) (ys.take k) := by
  repeat' intro
  simp [List.map_zipWith, List.take_zipWith]

theorem dgCert7 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [50042]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [50042]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_append, List.take_zipWith, List.map_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
