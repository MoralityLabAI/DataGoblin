theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap, List.reverse_reverse]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.append_assoc]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.reverse_reverse]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [31479]).flatMap f).reverse = ([31479] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap]

theorem dgCert6 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 34819) b) c + 34819 = Nat.gcd (a + 34819) (Nat.gcd c b) + 34819 := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 2 <;> apply Nat.gcd_comm

theorem dgCert7 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [69263]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [69263]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_append, List.drop_zipWith, List.map_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
