theorem dgCert0 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [56603]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [56603]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert1 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [56603]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [56603]).take k) (ys.take k) := by
  repeat' intro
  simp only [List.take_zipWith, List.map_zipWith]

theorem dgCert2 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 31479) b) c = Nat.gcd (a + 31479) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 1 <;> apply Nat.gcd_comm

theorem dgCert3 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 31479) b) c = Nat.gcd (a + 31479) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> exact congrArg (Nat.gcd _) (Nat.gcd_comm _ _)

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_append, List.reverse_flatMap]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap, List.reverse_reverse]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [61098]).flatMap f).reverse = ([61098] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap, List.reverse_reverse]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
