theorem dgCert0 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [69263]) ++ ys).filterMap f).map g = (xs ++ [69263]).filterMap (fun x => (f x).map g) ++ ys.filterMap (fun x => (f x).map g) := by
  repeat' intro
  simp only [List.filterMap_append, List.map_append, List.map_filterMap]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool) (k : Nat), ((((xs ++ [50042]).map f).dropWhile p).takeWhile q).drop k = ((((xs ++ [50042]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).drop k).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map, List.map_drop]

theorem dgCert2 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 50042) b) c + 50042 = Nat.gcd (a + 50042) (Nat.gcd c b) + 50042 := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 2 <;> apply Nat.gcd_comm

theorem dgCert3 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 39622) b) c = Nat.gcd (a + 39622) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 1 <;> apply Nat.gcd_comm

theorem dgCert4 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 39622) b) c = Nat.gcd (a + 39622) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> exact congrArg (Nat.gcd _) (Nat.gcd_comm _ _)

theorem dgCert5 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 56603) b) c + 56603 = Nat.gcd (a + 56603) (Nat.gcd c b) + 56603 := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 2 <;> apply Nat.gcd_comm

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool) (k : Nat), ((((xs ++ [56603]).map f).dropWhile p).takeWhile q).drop k = ((((xs ++ [56603]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).drop k).map f := by
  repeat' intro
  simp only [List.takeWhile_map, List.dropWhile_map, List.map_drop]

theorem dgCert7 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [31479]) ++ ys).filterMap f).map g = (xs ++ [31479]).filterMap (fun x => (f x).map g) ++ ys.filterMap (fun x => (f x).map g) := by
  repeat' intro
  simp only [List.filterMap_append, List.map_append, List.map_filterMap]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
