theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [50042]).take k).reverse).map f = (([50042].reverse ++ xs.reverse).map f).drop ((xs ++ [50042]).length - k) := by
  repeat' intro
  simp only [List.map_drop, List.reverse_append, List.reverse_take]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [50042]).take k).reverse).map f = (([50042].reverse ++ xs.reverse).map f).drop ((xs ++ [50042]).length - k) := by
  repeat' intro
  simp only [List.reverse_take, List.reverse_append, List.map_drop]

theorem dgCert2 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[69263]]).flatten.reverse).map f = (((xss ++ [[69263]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.flatten_append, List.reverse_flatten]

theorem dgCert3 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[69263]]).flatten.reverse).map f = (((xss ++ [[69263]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert4 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[69263]]).flatten.reverse).map f = (((xss ++ [[69263]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert5 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[69263]]).flatten.reverse).map f = (((xss ++ [[69263]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_flatten]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [65660]).take k).reverse).map f = (([65660].reverse ++ xs.reverse).map f).drop ((xs ++ [65660]).length - k) := by
  repeat' intro
  simp [List.map_append, List.map_drop, List.reverse_take]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [65660]).take k).reverse).map f = (([65660].reverse ++ xs.reverse).map f).drop ((xs ++ [65660]).length - k) := by
  repeat' intro
  simp [List.map_append, List.reverse_drop, List.reverse_take]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
