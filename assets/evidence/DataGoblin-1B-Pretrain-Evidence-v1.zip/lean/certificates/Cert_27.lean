theorem dgCert0 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp [List.reverse_take]

theorem dgCert1 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp only [List.reverse_append, List.reverse_take, List.length_drop]

theorem dgCert2 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp only [List.reverse_append, List.reverse_take]

theorem dgCert3 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp only [List.reverse_take, List.reverse_append]

theorem dgCert4 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[31479]]).flatten.reverse).map f = (((xss ++ [[31479]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.flatten_append, List.reverse_flatten]

theorem dgCert5 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[31479]]).flatten.reverse).map f = (((xss ++ [[31479]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert6 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[31479]]).flatten.reverse).map f = (((xss ++ [[31479]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert7 : ∀ (xss : List (List Nat)) (f : Nat → Nat), ((xss ++ [[31479]]).flatten.reverse).map f = (((xss ++ [[31479]]).map List.reverse).reverse.map (List.map f)).flatten := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_flatten]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
