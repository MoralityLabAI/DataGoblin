theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.append_assoc]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap, List.reverse_reverse]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [39622]).flatMap f).reverse = ([39622] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_flatMap]

theorem dgCert3 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_take, List.length_drop]

theorem dgCert4 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_take]

theorem dgCert5 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp [List.reverse_drop, List.reverse_take]

theorem dgCert6 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.drop_append]

theorem dgCert7 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [61098]).take k).reverse = ([61098].reverse ++ xs.reverse).drop ((xs ++ [61098]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.length_drop]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
