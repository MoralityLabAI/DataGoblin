theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).dropWhile p).takeWhile q = (((xs ++ [39622]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).dropWhile p).takeWhile q = (((xs ++ [39622]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [39622]).map f).dropWhile p).takeWhile q = (((xs ++ [39622]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).dropWhile p).takeWhile q = (((xs ++ [31479]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).dropWhile p).takeWhile q = (((xs ++ [31479]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [31479]).map f).dropWhile p).takeWhile q = (((xs ++ [31479]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).dropWhile p).takeWhile q = (((xs ++ [61098]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_append, List.takeWhile_map]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → Nat) (p q : Nat → Bool), (((xs ++ [61098]).map f).dropWhile p).takeWhile q = (((xs ++ [61098]).dropWhile (p ∘ f)).takeWhile (q ∘ f)).map f := by
  repeat' intro
  simp only [List.dropWhile_map, List.takeWhile_map, List.append_assoc]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
