theorem dgCert0 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [61098]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [61098]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert1 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [61098]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [61098]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_zipWith, List.map_zipWith]

theorem dgCert2 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [61098]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [61098]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert3 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [61098]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [61098]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_zipWith, List.map_zipWith]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_append, List.reverse_flatMap]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap, List.reverse_reverse]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.flatMap_append, List.reverse_flatMap]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → List Nat), ((xs ++ [69263]).flatMap f).reverse = ([69263] ++ xs.reverse).flatMap (List.reverse ∘ f) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_flatMap, List.reverse_reverse]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
