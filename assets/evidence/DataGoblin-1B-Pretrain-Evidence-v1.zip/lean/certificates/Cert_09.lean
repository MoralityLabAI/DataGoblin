theorem dgCert0 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.map_append, List.map_drop, List.reverse_take]

theorem dgCert1 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.map_append, List.reverse_drop, List.reverse_take]

theorem dgCert2 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.map_append, List.reverse_take]

theorem dgCert3 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.map_drop, List.reverse_append, List.reverse_take]

theorem dgCert4 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.map_drop, List.reverse_take]

theorem dgCert5 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.drop_append]

theorem dgCert6 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp [List.reverse_take]

theorem dgCert7 : ∀ (xs : List Nat) (f : Nat → Nat) (k : Nat), (((xs ++ [56603]).take k).reverse).map f = (([56603].reverse ++ xs.reverse).map f).drop ((xs ++ [56603]).length - k) := by
  repeat' intro
  simp only [List.map_drop, List.reverse_append, List.reverse_take]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
