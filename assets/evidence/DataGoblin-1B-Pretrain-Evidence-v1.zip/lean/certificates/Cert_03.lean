theorem dgCert0 : ∀ (xss : List (List Nat)), ((xss ++ [[31479]]).flatten.reverse).count 31479 = ((xss ++ [[31479]]).map (List.count 31479)).sum := by
  repeat' intro
  simp only [List.count_flatten, List.count_reverse, List.map_append]

theorem dgCert1 : ∀ (xss : List (List Nat)), ((xss ++ [[31479]]).flatten.reverse).count 31479 = ((xss ++ [[31479]]).map (List.count 31479)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.count_flatten]

theorem dgCert2 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [39622]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [39622]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert3 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [39622]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [39622]).drop k) (ys.drop k) := by
  repeat' intro
  simp [List.drop_zipWith, List.map_zipWith]

theorem dgCert4 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [39622]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [39622]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_append, List.drop_zipWith, List.map_zipWith]

theorem dgCert5 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [39622]) ys).drop k).map g = List.zipWith (fun a b => g (f a b)) ((xs ++ [39622]).drop k) (ys.drop k) := by
  repeat' intro
  simp only [List.drop_zipWith, List.map_zipWith]

theorem dgCert6 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [65660]) ++ ys).filterMap f).reverse.map g = (ys.filterMap (fun x => (f x).map g)).reverse ++ ((xs ++ [65660]).filterMap (fun x => (f x).map g)).reverse := by
  repeat' intro
  simp only [List.filterMap_append, List.reverse_append, List.map_reverse, List.map_append, List.map_filterMap]

theorem dgCert7 : ∀ (xss yss : List (List Nat)), (((xss ++ [[56603]]) ++ yss).flatten.reverse).count 56603 = (xss.map (List.count 56603)).sum + 1 + (yss.map (List.count 56603)).sum := by
  repeat' intro
  simp only [List.count_reverse, List.flatten_append, List.count_append, List.flatten_singleton, List.count_cons_self, List.count_nil, Nat.zero_add, List.count_flatten]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
