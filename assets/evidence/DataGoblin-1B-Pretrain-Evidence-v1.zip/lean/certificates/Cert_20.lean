theorem dgCert0 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_take, List.length_drop]

theorem dgCert1 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_take]

theorem dgCert2 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp [List.reverse_drop, List.reverse_take]

theorem dgCert3 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.drop_append]

theorem dgCert4 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.length_drop]

theorem dgCert5 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp [List.reverse_take]

theorem dgCert6 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp only [List.reverse_append, List.reverse_take, List.length_drop]

theorem dgCert7 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [39622]).take k).reverse = ([39622].reverse ++ xs.reverse).drop ((xs ++ [39622]).length - k) := by
  repeat' intro
  simp only [List.reverse_append, List.reverse_take]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
