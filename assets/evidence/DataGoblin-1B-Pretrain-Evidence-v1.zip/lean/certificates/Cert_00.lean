theorem dgCert0 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 61098) b) c = Nat.gcd (a + 61098) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> congr 1 <;> apply Nat.gcd_comm

theorem dgCert1 : ∀ (a b c : Nat), Nat.gcd (Nat.gcd (a + 61098) b) c = Nat.gcd (a + 61098) (Nat.gcd c b) := by
  repeat' intro
  rw [Nat.gcd_assoc] <;> exact congrArg (Nat.gcd _) (Nat.gcd_comm _ _)

theorem dgCert2 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_take, List.length_drop]

theorem dgCert3 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp [List.reverse_append, List.reverse_take]

theorem dgCert4 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp [List.reverse_drop, List.reverse_take]

theorem dgCert5 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.drop_append]

theorem dgCert6 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp [List.reverse_take, List.length_drop]

theorem dgCert7 : ∀ (xs : List Nat) (k : Nat), ((xs ++ [31479]).take k).reverse = ([31479].reverse ++ xs.reverse).drop ((xs ++ [31479]).length - k) := by
  repeat' intro
  simp [List.reverse_take]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
