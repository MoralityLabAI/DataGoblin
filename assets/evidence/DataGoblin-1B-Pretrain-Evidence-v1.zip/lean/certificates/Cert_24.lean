theorem dgCert0 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[34819]]).flatten.reverse).take k).map f = ((((xss ++ [[34819]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_append, List.reverse_flatten]

theorem dgCert1 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[34819]]).flatten.reverse).take k).map f = ((((xss ++ [[34819]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.map_take, List.reverse_flatten]

theorem dgCert2 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[34819]]).flatten.reverse).take k).map f = ((((xss ++ [[34819]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp [List.reverse_flatten]

theorem dgCert3 : ∀ (xss : List (List Nat)) (f : Nat → Nat) (k : Nat), (((xss ++ [[34819]]).flatten.reverse).take k).map f = ((((xss ++ [[34819]]).map List.reverse).reverse.map (List.map f)).flatten).take k := by
  repeat' intro
  simp only [List.reverse_flatten, List.map_take, List.map_flatten]

theorem dgCert4 : ∀ (xs ys : List Nat) (f : Nat → Option Nat) (g : Nat → Nat), (((xs ++ [61098]) ++ ys).filterMap f).map g = (xs ++ [61098]).filterMap (fun x => (f x).map g) ++ ys.filterMap (fun x => (f x).map g) := by
  repeat' intro
  simp only [List.filterMap_append, List.map_append, List.map_filterMap]

theorem dgCert5 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [34819]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [34819]).take k) (ys.take k) := by
  repeat' intro
  simp [List.map_zipWith, List.take_zipWith]

theorem dgCert6 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [34819]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [34819]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_append, List.take_zipWith, List.map_zipWith]

theorem dgCert7 : ∀ (f : Nat → Nat → Nat) (g : Nat → Nat) (xs ys : List Nat) (k : Nat), ((List.zipWith f (xs ++ [34819]) ys).map g).take k = List.zipWith (fun a b => g (f a b)) ((xs ++ [34819]).take k) (ys.take k) := by
  repeat' intro
  simp [List.take_zipWith, List.map_zipWith]

#print axioms dgCert0

#print axioms dgCert1

#print axioms dgCert2

#print axioms dgCert3

#print axioms dgCert4

#print axioms dgCert5

#print axioms dgCert6

#print axioms dgCert7
