"""MM06 independent scoped audit and registered-policy reimplementation."""
import argparse
import hashlib
import importlib.util
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from time import perf_counter
import zipfile

ZIP_SHA='c424d2c2c83f6d0d57797b2a113c78f13d14e7380c6f242a810af6e6b55870b4'
PARSER_SHA='2c761d69733f3b6a538c4545088c3b2ed53d1891e2da8dc37a597de206ad849d'
SOURCE='9c4bcad276eab5f8b17b231a4543cfe185c19c95cfb7940780dd1de265610c12'
BUDGETS=(8,16,32,64,128,256,512)
POLICIES=('hash_dfs','goal_dfs','beam4','memo_dfs')

def require(ok,msg):
    if not ok: raise ValueError(msg)

def sha(b): return hashlib.sha256(b).hexdigest()
def digest(x): return sha(json.dumps(x,sort_keys=True,separators=(',',':')).encode())

def family(sig):
    types={v:t for t,v in sig['floating']}; rename={}
    def token(s):
        if s not in types: return ['constant',s]
        return ['variable',types[s],rename.setdefault(s,len(rename))]
    goal=[token(s) for s in sig['statement']]
    hyp=[[token(s) for s in h] for h in sig['essential']]
    require(set(rename)==set(types),'unused mandatory variable')
    dv=sorted(sorted((rename[a],rename[b])) for a,b in sig['distinct'])
    return digest([goal,hyp,dv])

def load(archive,parser):
    require(sha(archive.read_bytes())==ZIP_SHA,'archive mismatch')
    require(sha(parser.read_bytes())==PARSER_SHA,'parser mismatch')
    spec=importlib.util.spec_from_file_location('mm04',parser)
    mm=importlib.util.module_from_spec(spec); spec.loader.exec_module(mm)
    with zipfile.ZipFile(archive) as z:
        r=json.loads(z.read('receipt.json'))
        require(r['schema']=='mm06-branching-v1' and r['source_sha256']==SOURCE,'source receipt')
        require(r['window']==[2401,4200] and r['verified_prefix_theorems']==4200,'window')
        for n,h in r['artifact_sha256'].items(): require(sha(z.read(n))==h,'hash '+n)
        rows=[json.loads(s) for s in z.read('inputs.jsonl').splitlines()]
        ys=[json.loads(s) for s in z.read('oracle.jsonl').splitlines()]
        proofs=[json.loads(s) for s in z.read('proofs.jsonl').splitlines()]
        prefix=z.read('expanded-prefix.mm'); c=json.loads(z.read('expanded-c.json'))['certificate']
        require(c['verified'] and not c['contradictory_summary'] and c['sha256']==sha(prefix),'C receipt')
        require('No errors were found.' in z.read('expanded-python.log').decode(),'Python receipt')
    oracle={y['id']:y for y in ys}
    require(len(rows)==len(ys)==len(oracle)==1346 and len({x['id'] for x in rows})==1346,'counts')
    require({x['id'] for x in rows}==set(oracle),'coverage')
    require(dict(Counter(x['split'] for x in rows))==r['splits'],'split counts')
    require(len(proofs)==4200,'proof count')
    pmap={p['label']:p for p in proofs}; prior={family(p['statement']) for p in proofs if p['source_index']<=2400}; seen={}
    for x in rows:
        p=pmap[x['id']]; f=family(p['statement'])
        require(p['source_index']==x['source_index'] and 2401<=x['source_index']<=4200,'index')
        require(f==x['family'] and f not in prior,'spent family')
        require(seen.setdefault(f,x['split'])==x['split'],'family split')
        k=int(digest([r['salt'],'split',f])[:16],16)%100
        require(x['split']==('train' if k<70 else 'dev' if k<85 else 'family_test'),'split hash')
        require(x['depth']==2+int(digest([r['salt'],'depth',f])[:16],16)%3,'depth hash')
    return mm,rows,oracle,mm.parse(prefix.decode('ascii')),r

class Root:
    def __init__(self,x,db,ordinal,mm):
        self.x=x; self.mm=mm; self.labels,scopes=db
        self.active,self.vs,self.dv,limit=scopes[x['id']]
        self.template,self.banks=x['template'],x['banks']; self.target=[x['target']]
        require(self.active==set(x['active_hypotheses']),'active hypotheses')
        require(self.vs==set(x['variables']) and self.dv=={tuple(p) for p in x['distinct']},'scope')
        require(self.labels[x['id']]['statement']==x['target'],'target')
        require([t for t in self.template if type(t) is int]==list(range(x['depth'])),'holes')
        require(len(self.banks)==x['depth'] and all(4<=len(b)<=6 and len(set(b))==len(b) for b in self.banks),'banks')
        refs={t for t in self.template if isinstance(t,str)}|{a for b in self.banks for a in b}
        require(all(ordinal[a]<limit and (self.labels[a]['kind'] in ('$a','$p') or a in self.active) for a in refs|set(x['prefix'])),'future or inactive label')
        require(set(x['signatures'])==refs,'signature coverage')
        require(all(self.labels[a]==s for a,s in x['signatures'].items()),'signature mismatch')
        require(all(self.labels[a]==s for a,s in x['active_hypotheses'].items()),'hypothesis mismatch')
        self.initial=[]
        for a in x['prefix']:
            self.initial=self.step(self.initial,a); require(self.initial is not None,'prefix invalid')
        require(self.initial==x['prefix_stack'],'prefix mismatch')
        self.tc=Counter(x['target'])
    def step(self,s,a): return self.mm.step(s,self.labels[a],self.vs,self.dv)
    def rank(self,s):
        top=s[-1] if s else []
        return (top==self.x['target'],2*sum((Counter(top)&self.tc).values())/max(1,len(top)+len(self.x['target'])))
    def audit(self):
        sols=[]; calls=0
        def visit(pos,s,path):
            nonlocal calls
            while pos<len(self.template) and isinstance(self.template[pos],str):
                calls+=1; s=self.step(s,self.template[pos]); pos+=1
                if s is None:return
            if pos==len(self.template):
                if s==self.target:sols.append(path)
                return
            for a in self.banks[self.template[pos]]:
                calls+=1; after=self.step(s,a)
                if after is not None:visit(pos+1,after,path+(a,))
        visit(0,self.initial,())
        return sols,calls

class Exhausted(Exception):pass
class Found(Exception):
    def __init__(self,path):self.path=path

class Search:
    def __init__(self,r,budget):
        self.r=r; self.budget=budget; self.calls=0; self.hits=[]; self.drops=[]; self.dead=set()
    def step(self,s,a):
        if self.calls>=self.budget:raise Exhausted()
        self.calls+=1; return self.r.step(s,a)
    def advance(self,pos,s,path):
        while pos<len(self.r.template) and isinstance(self.r.template[pos],str):
            s=self.step(s,self.r.template[pos]);pos+=1
            if s is None:return pos,None
        if pos==len(self.r.template) and s==self.r.target:raise Found(path)
        return pos,s
    def dfs(self,pos,s,path,goal=False,memo=False):
        pos,s=self.advance(pos,s,path)
        if s is None or pos==len(self.r.template):return
        key=(pos,tuple(tuple(t) for t in s)) if memo else None
        if memo and key in self.dead:
            self.hits.append(self.calls);return
        bank=self.r.banks[self.r.template[pos]]
        if goal:
            children=[]
            for a in bank:
                after=self.step(s,a)
                if after is not None:
                    if pos+1==len(self.r.template) and after==self.r.target:raise Found(path+(a,))
                    children.append((a,after))
            children.sort(key=lambda q:self.r.rank(q[1]),reverse=True)
            for a,after in children:self.dfs(pos+1,after,path+(a,),goal=True)
        else:
            for a in bank:
                after=self.step(s,a)
                if after is not None:self.dfs(pos+1,after,path+(a,),memo=memo)
        if memo:self.dead.add(key)
    def beam(self):
        frontier=[(0,self.r.initial,())]
        while frontier:
            children=[]
            for pos,s,path in frontier:
                pos,s=self.advance(pos,s,path)
                if s is None or pos==len(self.r.template):continue
                for a in self.r.banks[self.r.template[pos]]:
                    after=self.step(s,a)
                    if after is not None:
                        chosen=path+(a,); j,after=self.advance(pos+1,after,chosen)
                        if after is not None and j<len(self.r.template):children.append((j,after,chosen))
            children.sort(key=lambda q:self.r.rank(q[1]),reverse=True)
            self.drops.extend([self.calls]*max(0,len(children)-4)); frontier=children[:4]
    def run(self,policy):
        cert=None
        try:
            if policy=='beam4':self.beam()
            else:self.dfs(0,self.r.initial,(),goal=policy=='goal_dfs',memo=policy=='memo_dfs')
            status='pruned' if self.drops else 'exhausted'
        except Found as f:cert=list(f.path);status='solved'
        except Exhausted:status='budget'
        return dict(certificate=cert,calls=self.calls,status=status,hits=self.hits,drops=self.drops)

def metrics(results):
    groups=defaultdict(list); report={}
    for r in results:
        groups[r['split'],'all'].append(r);groups[r['split'],str(r['depth'])].append(r)
    for (split,depth),rows in sorted(groups.items()):
        group={}
        for p in POLICIES:
            out={}
            for b in BUDGETS:
                solved=calls=hits=drops=unresolved=pruned=exhausted=0
                for r in rows:
                    a=r['policies'][p]; success=a['status']=='solved' and a['calls']<=b
                    solved+=success;calls+=min(a['calls'],b)
                    hits+=sum(t<=b for t in a['hits']);drops+=sum(t<=b for t in a['drops'])
                    if not success:
                        if a['calls']>b or a['status']=='budget':unresolved+=1
                        elif a['status']=='pruned':pruned+=1
                        else:exhausted+=1
                out[str(b)]=dict(n=len(rows),solved=solved,transitions=calls,memo_hits=hits,beam_drops=drops,budget_unresolved=unresolved,pruned_unsolved=pruned,exhausted_unsolved=exhausted)
            group[p]=out
        report.setdefault(split,{})[depth]=group
    return report

def main():
    p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--mm04',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    started=perf_counter();mm,rows,oracle,db,receipt=load(a.archive,a.mm04)
    ordinal={v:i+1 for i,v in enumerate(db[0])};transitions=alternatives=interaction=0; multi=Counter();results=[]
    for x in rows:
        root=Root(x,db,ordinal,mm);sols,calls=root.audit();y=oracle[x['id']];valid={tuple(s) for s in y['accepted']}
        require(set(sols)==valid and len(sols)==len(valid) and tuple(y['reference']) in valid,'oracle mismatch '+x['id'])
        require(calls==y['exhaustive_transitions'],'transition census '+x['id'])
        transitions+=calls;alternatives+=len(valid)-1
        product=math.prod(len({s[j] for s in valid}) for j in range(x['depth']));nonproduct=product!=len(valid)
        interaction+=nonproduct;multi[str(x['depth'])]+=nonproduct
        r=dict(id=x['id'],split=x['split'],depth=x['depth'],family=x['family'],solutions=len(valid),marginal_combinations=product,policies={})
        for policy in POLICIES:
            s=Search(root,max(BUDGETS)).run(policy)
            if s['certificate'] is not None:require(tuple(s['certificate']) in valid,'false certificate '+x['id'])
            r['policies'][policy]=s
        results.append(r)
        if len(results)%200==0:print('audited',len(results),'transitions',transitions,'seconds',round(perf_counter()-started,1),flush=True)
    require(transitions==receipt['exhaustive_transitions'] and alternatives==receipt['alternative_tuples'],'aggregate census')
    report=dict(schema='mm06-search-v1',archive_sha256=ZIP_SHA,runner_sha256=sha(Path(__file__).read_bytes()),mm04_sha256=PARSER_SHA,audited_roots=len(results),exhaustive_transitions=transitions,oracle_disagreements=0,alternative_tuples=alternatives,noncartesian_valid_marginals=interaction,noncartesian_by_depth=dict(multi),budgets=BUDGETS,policies=POLICIES,results=metrics(results),elapsed_seconds=round(perf_counter()-started,3),scope='Reimplemented registered policies; public alpha-family test; live local primitive replay; lower budgets are deterministic prefixes of max-budget execution.')
    a.out.mkdir(parents=True,exist_ok=True);(a.out/'roots.jsonl').write_text(''.join(json.dumps(r,sort_keys=True)+'\n' for r in results));report['roots_sha256']=sha((a.out/'roots.jsonl').read_bytes());(a.out/'receipt.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2),flush=True)
    for p in POLICIES:print(p,report['results']['family_test']['all'][p],flush=True)

if __name__=='__main__':main()
